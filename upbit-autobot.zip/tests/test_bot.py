"""
자동매매 봇 테스트
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from strategies.aggressive_scalping import AggressiveScalping
from strategies.conservative_scalping import ConservativeScalping
from strategies.mean_reversion import MeanReversion
from strategies.grid_trading import GridTrading
from utils.risk_manager import RiskManager


class MockUpbitAPI:
    """테스트용 모의 Upbit API"""
    
    def __init__(self, initial_balance=500000):
        self.balance = initial_balance
    
    def get_balance(self, ticker='KRW'):
        """잔고 조회"""
        if ticker == 'KRW':
            return self.balance
        return 0
    
    def deposit(self, amount):
        """입금 시뮬레이션"""
        self.balance += amount
    
    def withdraw(self, amount):
        """출금 시뮬레이션"""
        self.balance -= amount


def generate_sample_ohlcv(length=200, trend='sideways'):
    """
    샘플 OHLCV 데이터 생성
    
    Args:
        length: 데이터 길이
        trend: 추세 (uptrend, downtrend, sideways)
    
    Returns:
        DataFrame
    """
    dates = pd.date_range(end=datetime.now(), periods=length, freq='5min')
    
    base_price = 50000000  # 5천만원 (비트코인 가격)
    
    if trend == 'uptrend':
        trend_factor = np.linspace(0, 0.1, length)
    elif trend == 'downtrend':
        trend_factor = np.linspace(0, -0.1, length)
    else:
        trend_factor = np.zeros(length)
    
    # 랜덤 변동
    noise = np.random.randn(length) * 0.01
    
    prices = base_price * (1 + trend_factor + noise)
    
    df = pd.DataFrame({
        'open': prices * 0.998,
        'high': prices * 1.002,
        'low': prices * 0.997,
        'close': prices,
        'volume': np.random.randint(100, 1000, length),
        'value': np.random.randint(1000000, 10000000, length)
    }, index=dates)
    
    return df


class TestStrategies:
    """전략 테스트"""
    
    def test_aggressive_scalping_buy_signal(self):
        """극공격적 단타 매수 신호 테스트"""
        config = {
            'stop_loss': 0.02,
            'take_profit': 0.015,
            'rsi_oversold': 30,
            'rsi_overbought': 70,
            'volume_threshold': 1.5,
            'min_price_change': 0.01
        }
        
        strategy = AggressiveScalping(config)
        df = generate_sample_ohlcv(200, trend='downtrend')
        
        signal, reason, indicators = strategy.generate_signal(df, 'KRW-BTC')
        
        assert signal in ['BUY', 'SELL', 'HOLD']
        assert 'rsi' in indicators
        assert 'volume_ratio' in indicators
    
    def test_conservative_scalping_buy_signal(self):
        """보수적 단타 매수 신호 테스트"""
        config = {
            'stop_loss': 0.015,
            'take_profit': 0.01,
            'rsi_min': 40,
            'rsi_max': 60,
            'bb_threshold': 0.95
        }
        
        strategy = ConservativeScalping(config)
        df = generate_sample_ohlcv(200, trend='sideways')
        
        signal, reason, indicators = strategy.generate_signal(df, 'KRW-BTC')
        
        assert signal in ['BUY', 'SELL', 'HOLD']
        assert 'bb_position' in indicators
    
    def test_mean_reversion_signal(self):
        """평균 회귀 신호 테스트"""
        config = {
            'stop_loss': 0.03,
            'take_profit': 0.025,
            'ma_period': 20,
            'deviation_threshold': 0.05
        }
        
        strategy = MeanReversion(config)
        df = generate_sample_ohlcv(200, trend='sideways')
        
        signal, reason, indicators = strategy.generate_signal(df, 'KRW-BTC')
        
        assert signal in ['BUY', 'SELL', 'HOLD']
        assert 'deviation' in indicators
    
    def test_grid_trading_initialization(self):
        """그리드 거래 초기화 테스트"""
        config = {
            'stop_loss': 0.04,
            'grid_count': 10,
            'grid_spacing': 0.005,
            'max_volatility': 0.02
        }
        
        strategy = GridTrading(config)
        strategy.initialize_grids(50000000)
        
        assert strategy.grid_initialized == True
        assert len(strategy.grids) > 0
        assert strategy.base_price == 50000000


class TestRiskManager:
    """리스크 관리자 테스트"""
    
    def test_risk_manager_initialization(self):
        """리스크 관리자 초기화 테스트"""
        rm = RiskManager(
            initial_capital=500000,
            max_daily_loss=50000,
            max_cumulative_loss=100000,
            max_positions=3,
            max_position_ratio=0.3
        )
        
        assert rm.current_balance == 500000
        assert rm.max_daily_loss == 50000
        assert rm.max_cumulative_loss == 100000
    
    def test_can_open_position(self):
        """포지션 개설 가능 여부 테스트"""
        rm = RiskManager(500000, 50000, 100000)
        
        can_open, msg = rm.can_open_position('KRW-BTC')
        assert can_open == True
    
    def test_add_position(self):
        """포지션 추가 테스트"""
        rm = RiskManager(500000, 50000, 100000)
        
        success = rm.add_position(
            ticker='KRW-BTC',
            amount=0.001,
            price=50000000,
            strategy='test'
        )
        
        assert success == True
        assert 'KRW-BTC' in rm.positions
        assert rm.current_balance < 500000
    
    def test_close_position(self):
        """포지션 청산 테스트"""
        rm = RiskManager(500000, 50000, 100000)
        
        # 포지션 추가
        rm.add_position('KRW-BTC', 0.001, 50000000, 'test')
        
        # 포지션 청산 (수익)
        profit_loss = rm.close_position('KRW-BTC', 51000000)
        
        assert profit_loss is not None
        assert profit_loss > 0
        assert 'KRW-BTC' not in rm.positions
    
    def test_max_positions_limit(self):
        """최대 포지션 수 제한 테스트"""
        rm = RiskManager(500000, 50000, 100000, max_positions=2)
        
        rm.add_position('KRW-BTC', 0.001, 50000000, 'test')
        rm.add_position('KRW-ETH', 0.01, 3000000, 'test')
        
        can_open, msg = rm.can_open_position('KRW-XRP')
        assert can_open == False
    
    def test_daily_loss_limit(self):
        """일일 손실 한도 테스트"""
        rm = RiskManager(500000, 50000, 100000)
        
        # 큰 손실 발생 (여러 번 - 더 큰 손실)
        for i in range(5):
            rm.add_position(f'KRW-BTC{i}', 0.002, 50000000, 'test')  # 10만원 투자
            rm.close_position(f'KRW-BTC{i}', 45000000)  # 10% 손실 (약 -1만원)
        
        # 총 약 -5만원 이상 손실로 한도 초과
        print(f"일일 손실: {rm.daily_profit_loss}")
        can_open, msg = rm.can_open_position('KRW-ETH')
        assert can_open == False
        assert rm.is_trading_stopped == True
    
    def test_win_rate_calculation(self):
        """승률 계산 테스트"""
        rm = RiskManager(500000, 50000, 100000)
        
        # 승리 거래
        rm.add_position('KRW-BTC', 0.001, 50000000, 'test')
        rm.close_position('KRW-BTC', 51000000)
        
        # 패배 거래
        rm.add_position('KRW-ETH', 0.01, 3000000, 'test')
        rm.close_position('KRW-ETH', 2900000)
        
        win_rate = rm.get_win_rate()
        assert win_rate == 50.0
    
    def test_balance_sync_deposit(self):
        """외부 입금 시 잔고 동기화 테스트"""
        mock_api = MockUpbitAPI(initial_balance=500000)
        rm = RiskManager(500000, 50000, 100000, upbit_api=mock_api)
        
        # 초기 잔고 확인
        assert rm.current_balance == 500000
        
        # 외부에서 200,000원 입금
        mock_api.deposit(200000)
        
        # 동기화 전에는 봇이 모름
        assert rm.current_balance == 500000
        
        # 동기화 실행
        sync_result = rm.sync_balance_from_exchange()
        
        # 동기화 성공
        assert sync_result == True
        assert rm.current_balance == 700000
    
    def test_balance_sync_withdrawal(self):
        """외부 출금 시 잔고 동기화 테스트"""
        mock_api = MockUpbitAPI(initial_balance=500000)
        rm = RiskManager(500000, 50000, 100000, upbit_api=mock_api)
        
        # 외부에서 100,000원 출금
        mock_api.withdraw(100000)
        
        # 동기화 실행
        rm.sync_balance_from_exchange()
        
        # 잔고 감소 확인
        assert rm.current_balance == 400000
    
    def test_balance_sync_small_difference(self):
        """작은 잔고 차이는 무시 테스트"""
        mock_api = MockUpbitAPI(initial_balance=500500)  # 500원 차이
        rm = RiskManager(500000, 50000, 100000, upbit_api=mock_api)
        
        # 동기화 실행
        rm.sync_balance_from_exchange()
        
        # 1000원 미만 차이는 무시됨
        assert rm.current_balance == 500000
    
    def test_position_size_after_deposit(self):
        """입금 후 포지션 크기 자동 조정 테스트"""
        mock_api = MockUpbitAPI(initial_balance=500000)
        rm = RiskManager(500000, 50000, 100000, max_position_ratio=0.3, upbit_api=mock_api)
        
        # 초기 포지션 크기
        initial_size = rm.calculate_position_size(50000000)
        assert initial_size == 500000 * 0.3  # 150,000원
        
        # 200,000원 입금
        mock_api.deposit(200000)
        
        # 강제 동기화 후 포지션 크기
        new_size = rm.calculate_position_size(50000000, force_sync=True)
        assert rm.current_balance == 700000
        assert new_size == 700000 * 0.3  # 210,000원


if __name__ == "__main__":
    pytest.main([__file__, '-v'])
