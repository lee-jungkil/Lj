# 📦 Upbit AutoProfit Bot - 전체 코드 다운로드

## 🎯 다운로드 방법

### 방법 1: ZIP 파일 다운로드 (권장)

**파일 위치**: `/home/user/webapp/upbit-autobot.zip`  
**파일 크기**: 36KB

```bash
# 현재 위치에서 복사
cp /home/user/webapp/upbit-autobot.zip .

# 압축 해제
unzip upbit-autobot.zip -d upbit-autobot

# 프로젝트 디렉토리로 이동
cd upbit-autobot
```

### 방법 2: TAR.GZ 파일 다운로드

**파일 위치**: `/home/user/upbit-autobot.tar.gz`  
**파일 크기**: 58KB

```bash
# 현재 위치에서 복사
cp /home/user/upbit-autobot.tar.gz .

# 압축 해제
tar -xzf upbit-autobot.tar.gz -C upbit-autobot

# 프로젝트 디렉토리로 이동
cd upbit-autobot
```

### 방법 3: Git Clone (현재 디렉토리 복사)

```bash
# 프로젝트 디렉토리 전체 복사
cp -r /home/user/webapp /your/destination/path

# 또는 rsync 사용
rsync -av --exclude='.git' /home/user/webapp/ /your/destination/path/
```

---

## 📂 압축 파일 내용

```
upbit-autobot/
├── README.md                    # 프로젝트 문서
├── QUICKSTART.py                # 빠른 시작 가이드
├── requirements.txt             # Python 패키지 의존성
├── .env.example                 # 환경변수 설정 예시
│
├── src/                         # 소스 코드
│   ├── main.py                  # 메인 봇 엔진
│   ├── config.py                # 설정 관리
│   ├── upbit_api.py             # Upbit API 래퍼
│   │
│   ├── strategies/              # 매매 전략 모듈
│   │   ├── base_strategy.py
│   │   ├── aggressive_scalping.py
│   │   ├── conservative_scalping.py
│   │   ├── mean_reversion.py
│   │   └── grid_trading.py
│   │
│   └── utils/                   # 유틸리티 모듈
│       ├── logger.py
│       ├── risk_manager.py
│       └── sentiment_analyzer.py
│
├── tests/                       # 테스트 코드
│   └── test_bot.py
│
└── trading_logs/                # 로그 저장 디렉토리
```

---

## 🚀 설치 및 실행

### 1. 압축 해제 후

```bash
# 가상환경 생성
python -m venv venv

# 가상환경 활성화
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate    # Windows

# 의존성 설치
pip install -r requirements.txt
```

### 2. 환경 설정

```bash
# .env 파일 생성
cp .env.example .env

# .env 파일 편집 (API 키 입력)
nano .env  # 또는 다른 편집기 사용
```

### 3. 봇 실행

```bash
# 백테스트 모드 (API 키 불필요)
python src/main.py --mode backtest

# 실거래 모드 (⚠️ 실제 자금 사용)
python src/main.py --mode live
```

---

## 📊 포함된 파일 목록

| 파일 | 라인 수 | 설명 |
|------|---------|------|
| `src/main.py` | 442 | 메인 봇 엔진 (24시간 운영) |
| `src/upbit_api.py` | 327 | Upbit API 통합 |
| `src/config.py` | 188 | 설정 관리 |
| `src/utils/risk_manager.py` | 324 | 리스크 관리 시스템 |
| `src/utils/logger.py` | 254 | 로깅 시스템 |
| `src/utils/sentiment_analyzer.py` | 210 | 감정 분석 |
| `src/strategies/base_strategy.py` | 157 | 전략 베이스 클래스 |
| `src/strategies/aggressive_scalping.py` | 88 | 극공격적 단타 |
| `src/strategies/conservative_scalping.py` | 91 | 보수적 단타 |
| `src/strategies/mean_reversion.py` | 95 | 평균 회귀 |
| `src/strategies/grid_trading.py` | 144 | 그리드 거래 |
| `tests/test_bot.py` | 197 | 단위 테스트 |
| **총계** | **2,839** | **전체 코드** |

---

## 🔧 주요 기능

### ✅ 완전한 자동매매 시스템
- 24시간 논스톱 운영
- 4가지 전략 (극공격적 단타, 보수적 단타, 평균회귀, 그리드)
- 시간대별 전략 자동 조정
- 감정 분석 기반 시장 대응

### ✅ 안전한 리스크 관리
- 일일 손실 한도: -50,000원
- 누적 손실 한도: -100,000원
- 자동 손절/익절
- 포지션 크기 제한

### ✅ 완벽한 로깅
- JSON 형식 거래 로그
- 컬러 콘솔 출력
- 월별 성과 리포트
- 에러 추적

---

## ⚠️ 중요 참고사항

### 실행 전 필수 확인
1. ✅ `.env` 파일에 Upbit API 키 입력
2. ✅ 백테스트 모드로 먼저 테스트
3. ✅ 소액으로 시작 (초기 자본: 50만원)
4. ✅ 손실 한도 설정 확인

### 보안 주의사항
- 🔒 API 키를 절대 공유하지 마세요
- 🔒 `.env` 파일을 Git에 올리지 마세요
- 🔒 실거래 모드는 신중하게 사용하세요

---

## 📞 문의 및 지원

문제가 발생하면:
1. `README.md` 확인
2. `QUICKSTART.py` 가이드 참고
3. `tests/test_bot.py` 테스트 실행
4. 로그 파일 확인 (`trading_logs/`)

---

## 📝 라이센스

MIT License - 자유롭게 사용, 수정, 배포 가능

**⚠️ 면책 조항**: 암호화폐 거래는 고위험 투자입니다. 이 봇을 사용하여 발생하는 모든 손실에 대해 개발자는 책임지지 않습니다.

---

**제작일**: 2024-02-10  
**총 코드 라인**: 2,839 라인  
**파일 수**: 19개  
**압축 크기**: 36KB (ZIP), 58KB (TAR.GZ)
