"""
Upbit API 래퍼 클래스
pyupbit 라이브러리를 사용하여 Upbit 거래소 API와 통신
"""

import pyupbit
import time
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import pandas as pd


class UpbitAPI:
    """Upbit API 래퍼 클래스"""
    
    def __init__(self, access_key: str = "", secret_key: str = ""):
        """
        초기화
        
        Args:
            access_key: Upbit Access Key
            secret_key: Upbit Secret Key
        """
        self.access_key = access_key
        self.secret_key = secret_key
        
        # 실거래용 객체 (키가 있을 때만)
        self.upbit = None
        if access_key and secret_key:
            try:
                self.upbit = pyupbit.Upbit(access_key, secret_key)
                print("✅ Upbit API 연결 성공")
            except Exception as e:
                print(f"⚠️ Upbit API 연결 실패: {e}")
                self.upbit = None
    
    # ==================== 시장 정보 ====================
    
    def get_all_tickers(self, fiat: str = "KRW") -> List[str]:
        """
        모든 티커 목록 가져오기
        
        Args:
            fiat: 기준 화폐 (KRW, BTC, USDT)
        
        Returns:
            티커 목록
        """
        try:
            tickers = pyupbit.get_tickers(fiat=fiat)
            return tickers
        except Exception as e:
            print(f"❌ 티커 조회 실패: {e}")
            return []
    
    def get_current_price(self, ticker: str) -> Optional[float]:
        """
        현재가 조회
        
        Args:
            ticker: 코인 티커 (예: KRW-BTC)
        
        Returns:
            현재가
        """
        try:
            price = pyupbit.get_current_price(ticker)
            return float(price) if price else None
        except Exception as e:
            print(f"❌ {ticker} 현재가 조회 실패: {e}")
            return None
    
    def get_orderbook(self, ticker: str) -> Optional[Dict]:
        """
        호가 정보 조회
        
        Args:
            ticker: 코인 티커
        
        Returns:
            호가 정보
        """
        try:
            orderbook = pyupbit.get_orderbook(ticker)
            return orderbook
        except Exception as e:
            print(f"❌ {ticker} 호가 조회 실패: {e}")
            return None
    
    def get_ohlcv(self, ticker: str, interval: str = "minute5", count: int = 200) -> Optional[pd.DataFrame]:
        """
        OHLCV (봉 차트) 데이터 조회
        
        Args:
            ticker: 코인 티커
            interval: 시간 간격 (minute1, minute5, minute15, minute30, hour, day, week, month)
            count: 조회할 데이터 개수
        
        Returns:
            OHLCV DataFrame
        """
        try:
            df = pyupbit.get_ohlcv(ticker, interval=interval, count=count)
            return df
        except Exception as e:
            print(f"❌ {ticker} OHLCV 조회 실패: {e}")
            return None
    
    # ==================== 계좌 정보 ====================
    
    def get_balance(self, ticker: str = "KRW") -> float:
        """
        잔고 조회
        
        Args:
            ticker: 화폐 또는 코인 (KRW, BTC, ETH 등)
        
        Returns:
            잔고
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return 0.0
        
        try:
            balance = self.upbit.get_balance(ticker)
            return float(balance) if balance else 0.0
        except Exception as e:
            print(f"❌ {ticker} 잔고 조회 실패: {e}")
            return 0.0
    
    def get_balances(self) -> List[Dict]:
        """
        전체 잔고 조회
        
        Returns:
            잔고 목록
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return []
        
        try:
            balances = self.upbit.get_balances()
            return balances if balances else []
        except Exception as e:
            print(f"❌ 전체 잔고 조회 실패: {e}")
            return []
    
    def get_amount(self, ticker: str) -> float:
        """
        특정 코인 보유량 조회
        
        Args:
            ticker: 코인 티커 (예: BTC, ETH)
        
        Returns:
            보유량
        """
        if not self.upbit:
            return 0.0
        
        try:
            # KRW-BTC -> BTC 추출
            if '-' in ticker:
                ticker = ticker.split('-')[1]
            
            amount = self.upbit.get_amount(ticker)
            return float(amount) if amount else 0.0
        except Exception as e:
            print(f"❌ {ticker} 보유량 조회 실패: {e}")
            return 0.0
    
    def get_avg_buy_price(self, ticker: str) -> float:
        """
        평균 매수가 조회
        
        Args:
            ticker: 코인 티커
        
        Returns:
            평균 매수가
        """
        if not self.upbit:
            return 0.0
        
        try:
            if '-' in ticker:
                ticker = ticker.split('-')[1]
            
            avg_price = self.upbit.get_avg_buy_price(ticker)
            return float(avg_price) if avg_price else 0.0
        except Exception as e:
            print(f"❌ {ticker} 평균 매수가 조회 실패: {e}")
            return 0.0
    
    # ==================== 주문 ====================
    
    def buy_market_order(self, ticker: str, price: float) -> Optional[Dict]:
        """
        시장가 매수
        
        Args:
            ticker: 코인 티커
            price: 매수 금액 (KRW)
        
        Returns:
            주문 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.buy_market_order(ticker, price)
            print(f"✅ 매수 주문 성공: {ticker}, {price:,.0f}원")
            return result
        except Exception as e:
            print(f"❌ 매수 주문 실패: {ticker}, {e}")
            return None
    
    def sell_market_order(self, ticker: str, volume: float) -> Optional[Dict]:
        """
        시장가 매도
        
        Args:
            ticker: 코인 티커
            volume: 매도 수량
        
        Returns:
            주문 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.sell_market_order(ticker, volume)
            print(f"✅ 매도 주문 성공: {ticker}, {volume}")
            return result
        except Exception as e:
            print(f"❌ 매도 주문 실패: {ticker}, {e}")
            return None
    
    def buy_limit_order(self, ticker: str, price: float, volume: float) -> Optional[Dict]:
        """
        지정가 매수
        
        Args:
            ticker: 코인 티커
            price: 매수 가격
            volume: 매수 수량
        
        Returns:
            주문 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.buy_limit_order(ticker, price, volume)
            print(f"✅ 지정가 매수 주문 성공: {ticker}, {price:,.0f}원, {volume}")
            return result
        except Exception as e:
            print(f"❌ 지정가 매수 실패: {ticker}, {e}")
            return None
    
    def sell_limit_order(self, ticker: str, price: float, volume: float) -> Optional[Dict]:
        """
        지정가 매도
        
        Args:
            ticker: 코인 티커
            price: 매도 가격
            volume: 매도 수량
        
        Returns:
            주문 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.sell_limit_order(ticker, price, volume)
            print(f"✅ 지정가 매도 주문 성공: {ticker}, {price:,.0f}원, {volume}")
            return result
        except Exception as e:
            print(f"❌ 지정가 매도 실패: {ticker}, {e}")
            return None
    
    def cancel_order(self, uuid: str) -> Optional[Dict]:
        """
        주문 취소
        
        Args:
            uuid: 주문 ID
        
        Returns:
            취소 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.cancel_order(uuid)
            print(f"✅ 주문 취소 성공: {uuid}")
            return result
        except Exception as e:
            print(f"❌ 주문 취소 실패: {uuid}, {e}")
            return None
    
    def get_order(self, uuid: str) -> Optional[Dict]:
        """
        주문 조회
        
        Args:
            uuid: 주문 ID
        
        Returns:
            주문 정보
        """
        if not self.upbit:
            print("⚠️ API 키가 설정되지 않았습니다")
            return None
        
        try:
            result = self.upbit.get_order(uuid)
            return result
        except Exception as e:
            print(f"❌ 주문 조회 실패: {uuid}, {e}")
            return None
    
    # ==================== 유틸리티 ====================
    
    def get_24h_volume(self, ticker: str) -> float:
        """
        24시간 거래량 조회
        
        Args:
            ticker: 코인 티커
        
        Returns:
            24시간 거래량 (KRW)
        """
        try:
            df = self.get_ohlcv(ticker, interval="day", count=1)
            if df is not None and not df.empty:
                return float(df['value'].iloc[-1])
            return 0.0
        except Exception as e:
            print(f"❌ {ticker} 24시간 거래량 조회 실패: {e}")
            return 0.0
    
    def get_24h_change(self, ticker: str) -> float:
        """
        24시간 변동률 조회
        
        Args:
            ticker: 코인 티커
        
        Returns:
            변동률 (%)
        """
        try:
            df = self.get_ohlcv(ticker, interval="day", count=2)
            if df is not None and len(df) >= 2:
                prev_close = df['close'].iloc[-2]
                curr_close = df['close'].iloc[-1]
                change = ((curr_close - prev_close) / prev_close) * 100
                return float(change)
            return 0.0
        except Exception as e:
            print(f"❌ {ticker} 24시간 변동률 조회 실패: {e}")
            return 0.0
    
    def wait_for_order_complete(self, uuid: str, timeout: int = 60) -> bool:
        """
        주문 완료 대기
        
        Args:
            uuid: 주문 ID
            timeout: 타임아웃 (초)
        
        Returns:
            완료 여부
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            order = self.get_order(uuid)
            if order and order.get('state') == 'done':
                return True
            time.sleep(1)
        
        return False
    
    def is_market_open(self) -> bool:
        """
        시장 개장 여부 (암호화폐는 24시간이지만 점검 시간 체크)
        
        Returns:
            개장 여부
        """
        # 업비트는 24시간 거래이므로 항상 True
        # 단, 점검 시간이 있다면 추가 로직 필요
        return True
