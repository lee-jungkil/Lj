"""
설정 관리 모듈
환경변수 및 봇 설정을 중앙에서 관리
"""

import os
from typing import Dict, Any
from dotenv import load_dotenv

# 환경변수 로드
load_dotenv()


class Config:
    """봇 설정 클래스"""
    
    # Upbit API 설정
    UPBIT_ACCESS_KEY = os.getenv('UPBIT_ACCESS_KEY', '')
    UPBIT_SECRET_KEY = os.getenv('UPBIT_SECRET_KEY', '')
    
    # 자본 및 리스크 설정
    INITIAL_CAPITAL = int(os.getenv('INITIAL_CAPITAL', 500000))
    MAX_DAILY_LOSS = int(os.getenv('MAX_DAILY_LOSS', 50000))
    MAX_CUMULATIVE_LOSS = int(os.getenv('MAX_CUMULATIVE_LOSS', 100000))
    MAX_POSITIONS = int(os.getenv('MAX_POSITIONS', 3))
    MAX_POSITION_RATIO = float(os.getenv('MAX_POSITION_RATIO', 0.3))
    
    # 거래 모드
    TRADING_MODE = os.getenv('TRADING_MODE', 'backtest')  # backtest, paper, live
    
    # 로깅 설정
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    ENABLE_TRADING_LOG = os.getenv('ENABLE_TRADING_LOG', 'true').lower() == 'true'
    ENABLE_ERROR_LOG = os.getenv('ENABLE_ERROR_LOG', 'true').lower() == 'true'
    
    # 감정 분석 설정
    ENABLE_SENTIMENT = os.getenv('ENABLE_SENTIMENT', 'true').lower() == 'true'
    NEWS_API_KEY = os.getenv('NEWS_API_KEY', '')
    
    # 알림 설정 (선택)
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
    TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')
    
    # 전략별 설정
    STRATEGIES = {
        'aggressive_scalping': {
            'enabled': True,
            'stop_loss': 0.02,      # 2% 손절
            'take_profit': 0.015,   # 1.5% 익절
            'rsi_oversold': 30,
            'rsi_overbought': 70,
            'volume_threshold': 1.5,  # 평균 거래량 대비 150%
            'min_price_change': 0.01,  # 1% 이상 변동
        },
        'conservative_scalping': {
            'enabled': True,
            'stop_loss': 0.015,     # 1.5% 손절
            'take_profit': 0.01,    # 1% 익절
            'rsi_min': 40,
            'rsi_max': 60,
            'bb_threshold': 0.95,   # 볼린저 밴드 하단 95%
        },
        'mean_reversion': {
            'enabled': True,
            'stop_loss': 0.03,      # 3% 손절
            'take_profit': 0.025,   # 2.5% 익절
            'ma_period': 20,
            'deviation_threshold': 0.05,  # 5% 이탈
        },
        'grid_trading': {
            'enabled': True,
            'stop_loss': 0.04,      # 4% 손절 (전체 그리드)
            'grid_count': 10,
            'grid_spacing': 0.005,  # 0.5% 간격
            'max_volatility': 0.02,  # 2% 미만 변동성
        }
    }
    
    # 시간대별 전략 가중치
    TIME_STRATEGY_WEIGHTS = {
        'morning_rush': {  # 09:00-11:00
            'hours': [(9, 10, 11)],
            'aggressive_scalping': 0.4,
            'conservative_scalping': 0.3,
            'mean_reversion': 0.2,
            'grid_trading': 0.1,
        },
        'midday': {  # 11:00-14:00
            'hours': [(11, 12, 13, 14)],
            'aggressive_scalping': 0.2,
            'conservative_scalping': 0.4,
            'mean_reversion': 0.2,
            'grid_trading': 0.2,
        },
        'afternoon_rush': {  # 14:00-16:00
            'hours': [(14, 15, 16)],
            'aggressive_scalping': 0.35,
            'conservative_scalping': 0.35,
            'mean_reversion': 0.2,
            'grid_trading': 0.1,
        },
        'night': {  # 21:00-09:00
            'hours': [(21, 22, 23, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)],
            'aggressive_scalping': 0.15,
            'conservative_scalping': 0.25,
            'mean_reversion': 0.4,
            'grid_trading': 0.2,
        },
    }
    
    # 코인 화이트리스트 (거래할 코인 목록)
    WHITELIST_COINS = [
        'KRW-BTC',   # 비트코인
        'KRW-ETH',   # 이더리움
        'KRW-XRP',   # 리플
        'KRW-ADA',   # 카르다노
        'KRW-SOL',   # 솔라나
        'KRW-DOGE',  # 도지코인
        'KRW-MATIC', # 폴리곤
        'KRW-DOT',   # 폴카닷
        'KRW-AVAX',  # 아발란체
        'KRW-LINK',  # 체인링크
    ]
    
    # 수익 관리 설정
    PROFIT_MANAGEMENT = {
        'withdrawal_ratio': 0.5,  # 월간 수익의 50% 출금
        'reinvest_ratio': 0.5,    # 50% 재투자
        'check_day': 1,           # 매월 1일 확인
    }
    
    @classmethod
    def validate(cls) -> bool:
        """설정 유효성 검사"""
        if cls.TRADING_MODE == 'live':
            if not cls.UPBIT_ACCESS_KEY or not cls.UPBIT_SECRET_KEY:
                raise ValueError("실거래 모드에서는 Upbit API 키가 필수입니다!")
        
        if cls.INITIAL_CAPITAL < 5000:
            raise ValueError("초기 자본은 최소 5,000원 이상이어야 합니다!")
        
        return True
    
    @classmethod
    def get_strategy_config(cls, strategy_name: str) -> Dict[str, Any]:
        """특정 전략 설정 가져오기"""
        return cls.STRATEGIES.get(strategy_name, {})
    
    @classmethod
    def get_time_weights(cls, hour: int) -> Dict[str, float]:
        """현재 시간대의 전략 가중치 가져오기"""
        for period, config in cls.TIME_STRATEGY_WEIGHTS.items():
            if hour in config['hours'][0]:
                return {
                    'aggressive_scalping': config['aggressive_scalping'],
                    'conservative_scalping': config['conservative_scalping'],
                    'mean_reversion': config['mean_reversion'],
                    'grid_trading': config['grid_trading'],
                }
        
        # 기본값 (균등 분배)
        return {
            'aggressive_scalping': 0.25,
            'conservative_scalping': 0.25,
            'mean_reversion': 0.25,
            'grid_trading': 0.25,
        }
    
    @classmethod
    def is_live_mode(cls) -> bool:
        """실거래 모드 여부"""
        return cls.TRADING_MODE == 'live'
    
    @classmethod
    def is_paper_mode(cls) -> bool:
        """모의투자 모드 여부"""
        return cls.TRADING_MODE == 'paper'
    
    @classmethod
    def is_backtest_mode(cls) -> bool:
        """백테스트 모드 여부"""
        return cls.TRADING_MODE == 'backtest'


# 설정 검증
try:
    Config.validate()
except Exception as e:
    print(f"⚠️ 설정 오류: {e}")
    print("📝 .env 파일을 확인하세요!")
