"""
AutoProfit Bot - 메인 봇 엔진
24시간 자동매매 봇
"""

import time
import argparse
from datetime import datetime
from typing import Dict, List
import random

from config import Config
from upbit_api import UpbitAPI
from utils.logger import TradingLogger
from utils.risk_manager import RiskManager
from utils.sentiment_analyzer import SentimentAnalyzer
from strategies.aggressive_scalping import AggressiveScalping
from strategies.conservative_scalping import ConservativeScalping
from strategies.mean_reversion import MeanReversion
from strategies.grid_trading import GridTrading


class AutoProfitBot:
    """자동매매 봇"""
    
    def __init__(self, mode: str = 'backtest'):
        """
        초기화
        
        Args:
            mode: 거래 모드 (backtest, paper, live)
        """
        self.mode = mode
        
        # 설정 로드
        Config.TRADING_MODE = mode
        Config.validate()
        
        # 로거 초기화
        self.logger = TradingLogger()
        self.logger.log_info(f"🚀 AutoProfit Bot 시작 (모드: {mode})")
        
        # API 초기화
        if mode == 'live':
            self.api = UpbitAPI(Config.UPBIT_ACCESS_KEY, Config.UPBIT_SECRET_KEY)
        else:
            self.api = UpbitAPI()  # 백테스트/모의투자 모드
        
        # 리스크 관리자 초기화 (API 연결 포함)
        self.risk_manager = RiskManager(
            initial_capital=Config.INITIAL_CAPITAL,
            max_daily_loss=Config.MAX_DAILY_LOSS,
            max_cumulative_loss=Config.MAX_CUMULATIVE_LOSS,
            max_positions=Config.MAX_POSITIONS,
            max_position_ratio=Config.MAX_POSITION_RATIO,
            upbit_api=self.api if mode == 'live' else None
        )
        
        # 감정 분석기 초기화
        self.sentiment_analyzer = None
        if Config.ENABLE_SENTIMENT:
            self.sentiment_analyzer = SentimentAnalyzer(Config.NEWS_API_KEY)
        
        # 전략 초기화
        self.strategies = {
            'aggressive_scalping': AggressiveScalping(Config.get_strategy_config('aggressive_scalping')),
            'conservative_scalping': ConservativeScalping(Config.get_strategy_config('conservative_scalping')),
            'mean_reversion': MeanReversion(Config.get_strategy_config('mean_reversion')),
            'grid_trading': GridTrading(Config.get_strategy_config('grid_trading'))
        }
        
        # 거래할 코인 목록
        self.tickers = Config.WHITELIST_COINS
        
        # 마지막 거래 시간 추적
        self.last_trade_time = {}
        self.min_trade_interval = 60  # 최소 거래 간격 (초)
        
        # 실행 플래그
        self.running = False
    
    def get_current_strategy_weights(self) -> Dict[str, float]:
        """현재 시간대의 전략 가중치 가져오기"""
        current_hour = datetime.now().hour
        weights = Config.get_time_weights(current_hour)
        
        # 감정 분석 기반 조정
        if self.sentiment_analyzer:
            sentiment = self.sentiment_analyzer.get_market_sentiment()
            weights = self.sentiment_analyzer.get_sentiment_adjusted_weights(
                weights, sentiment['score']
            )
            
            self.logger.log_info(
                f"📊 시장 감정: {sentiment['label']} ({sentiment['score']:.2f})"
            )
        
        return weights
    
    def select_strategy(self, weights: Dict[str, float]) -> str:
        """가중치 기반 전략 선택"""
        strategies = list(weights.keys())
        probabilities = list(weights.values())
        
        selected = random.choices(strategies, weights=probabilities, k=1)[0]
        return selected
    
    def analyze_ticker(self, ticker: str, strategy_name: str):
        """
        티커 분석 및 거래 신호 생성
        
        Args:
            ticker: 코인 티커
            strategy_name: 사용할 전략 이름
        """
        try:
            # 최소 거래 간격 확인
            last_time = self.last_trade_time.get(ticker, 0)
            if time.time() - last_time < self.min_trade_interval:
                return
            
            # OHLCV 데이터 가져오기
            df = self.api.get_ohlcv(ticker, interval="minute5", count=200)
            if df is None or df.empty:
                return
            
            # 전략 선택
            strategy = self.strategies.get(strategy_name)
            if not strategy or not strategy.enabled:
                return
            
            # 신호 생성
            signal, reason, indicators = strategy.generate_signal(df, ticker)
            
            if signal != 'HOLD':
                self.logger.log_signal(ticker, signal, strategy_name, indicators)
            
            # 매수 신호 처리
            if signal == 'BUY':
                self.execute_buy(ticker, strategy_name, reason, indicators)
            
            # 매도 신호 처리 (포지션 보유 중일 때)
            elif signal == 'SELL' and ticker in self.risk_manager.positions:
                self.execute_sell(ticker, reason)
            
            # 기존 포지션 손익 체크
            self.check_positions(ticker, strategy)
            
        except Exception as e:
            self.logger.log_error("ANALYZE_ERROR", f"{ticker} 분석 실패", e)
    
    def execute_buy(self, ticker: str, strategy: str, reason: str, indicators: Dict):
        """
        매수 실행
        
        Args:
            ticker: 코인 티커
            strategy: 전략 이름
            reason: 매수 사유
            indicators: 지표 데이터
        """
        try:
            # 포지션 개설 가능 여부 확인
            can_open, msg = self.risk_manager.can_open_position(ticker)
            if not can_open:
                self.logger.log_warning(f"매수 불가: {ticker} - {msg}")
                return
            
            # 현재가 조회
            current_price = self.api.get_current_price(ticker)
            if not current_price:
                return
            
            # 투자 금액 계산
            investment = self.risk_manager.calculate_position_size(current_price)
            if investment < 5000:
                self.logger.log_warning(f"투자 금액 부족: {ticker} - {investment:,.0f}원")
                return
            
            # 수량 계산
            amount = investment / current_price
            
            # 실거래 모드에서만 실제 주문
            if self.mode == 'live' and self.api.upbit:
                order = self.api.buy_market_order(ticker, investment)
                if not order:
                    return
            else:
                self.logger.log_info(f"[모의거래] 매수: {ticker}, {investment:,.0f}원")
            
            # 포지션 추가
            success = self.risk_manager.add_position(
                ticker=ticker,
                amount=amount,
                price=current_price,
                strategy=strategy
            )
            
            if success:
                # 거래 로그
                self.logger.log_trade(
                    action='BUY',
                    ticker=ticker,
                    price=current_price,
                    amount=amount,
                    strategy=strategy,
                    reason=reason,
                    profit_loss=0.0,
                    balance=self.risk_manager.current_balance,
                    metadata=indicators
                )
                
                self.last_trade_time[ticker] = time.time()
            
        except Exception as e:
            self.logger.log_error("BUY_ERROR", f"{ticker} 매수 실패", e)
    
    def execute_sell(self, ticker: str, reason: str):
        """
        매도 실행
        
        Args:
            ticker: 코인 티커
            reason: 매도 사유
        """
        try:
            if ticker not in self.risk_manager.positions:
                return
            
            position = self.risk_manager.positions[ticker]
            
            # 현재가 조회
            current_price = self.api.get_current_price(ticker)
            if not current_price:
                return
            
            # 실거래 모드에서만 실제 주문
            if self.mode == 'live' and self.api.upbit:
                order = self.api.sell_market_order(ticker, position.amount)
                if not order:
                    return
            else:
                self.logger.log_info(f"[모의거래] 매도: {ticker}, {position.amount:.8f}")
            
            # 포지션 청산
            profit_loss = self.risk_manager.close_position(ticker, current_price)
            
            if profit_loss is not None:
                # 거래 로그
                self.logger.log_trade(
                    action='SELL',
                    ticker=ticker,
                    price=current_price,
                    amount=position.amount,
                    strategy=position.strategy,
                    reason=reason,
                    profit_loss=profit_loss,
                    balance=self.risk_manager.current_balance
                )
                
                self.last_trade_time[ticker] = time.time()
            
        except Exception as e:
            self.logger.log_error("SELL_ERROR", f"{ticker} 매도 실패", e)
    
    def check_positions(self, ticker: str, strategy):
        """
        포지션 손익 체크 및 자동 청산
        
        Args:
            ticker: 코인 티커
            strategy: 전략 객체
        """
        if ticker not in self.risk_manager.positions:
            return
        
        position = self.risk_manager.positions[ticker]
        current_price = self.api.get_current_price(ticker)
        
        if not current_price:
            return
        
        # 전략별 청산 조건 확인
        should_exit, exit_reason = strategy.should_exit(position.avg_buy_price, current_price)
        
        if should_exit:
            self.execute_sell(ticker, exit_reason)
    
    def update_all_positions(self):
        """모든 포지션 가격 업데이트"""
        if not self.risk_manager.positions:
            return
        
        prices = {}
        for ticker in self.risk_manager.positions.keys():
            price = self.api.get_current_price(ticker)
            if price:
                prices[ticker] = price
        
        self.risk_manager.update_positions(prices)
    
    def check_profit_withdrawal(self):
        """수익 출금 확인 및 처리"""
        should_withdraw, amount = self.risk_manager.should_withdraw_profit()
        
        if should_withdraw:
            self.logger.log_info(
                f"💰 월간 수익 출금: {amount:,.0f}원 (50% 자동 출금)"
            )
            self.logger.log_warning(
                "⚠️ 실제 출금은 Upbit에서 수동으로 진행하세요!"
            )
            
            # 리스크 관리자에 출금 처리
            self.risk_manager.process_profit_withdrawal(amount)
    
    def print_status(self):
        """현재 상태 출력"""
        risk_status = self.risk_manager.get_risk_status()
        positions = self.risk_manager.get_positions_summary()
        
        self.logger.log_info("=" * 60)
        self.logger.log_info(f"💼 잔고: {risk_status['current_balance']:,.0f}원")
        self.logger.log_info(f"💎 총 자산: {risk_status['total_equity']:,.0f}원")
        self.logger.log_info(f"📈 총 수익률: {risk_status['total_profit_loss_ratio']:+.2f}%")
        self.logger.log_info(f"📊 일일 손익: {risk_status['daily_profit_loss']:+,.0f}원")
        self.logger.log_info(f"🎯 승률: {risk_status['win_rate']:.1f}%")
        self.logger.log_info(f"🔢 총 거래: {risk_status['total_trades']}회")
        
        if positions:
            self.logger.log_info(f"📦 보유 포지션: {len(positions)}개")
            for pos in positions:
                self.logger.log_info(
                    f"  - {pos['ticker']}: "
                    f"{pos['amount']:.8f} "
                    f"(평균가: {pos['avg_buy_price']:,.0f}, "
                    f"손익: {pos['profit_loss_ratio']:+.2f}%)"
                )
        
        self.logger.log_info("=" * 60)
    
    def run(self):
        """봇 실행 (24시간 논스톱)"""
        self.running = True
        self.logger.log_info("🤖 봇 가동 시작!")
        
        cycle = 0
        
        try:
            while self.running:
                cycle += 1
                
                # 일일 통계 리셋
                self.risk_manager.reset_daily_stats()
                
                # 거래 정지 확인
                if self.risk_manager.is_trading_stopped:
                    self.logger.log_warning(
                        f"⛔ 거래 정지: {self.risk_manager.stop_reason}"
                    )
                    time.sleep(300)  # 5분 대기
                    continue
                
                # 시간대별 전략 가중치
                weights = self.get_current_strategy_weights()
                
                # 수익 출금 확인
                self.check_profit_withdrawal()
                
                # 각 티커 분석
                for ticker in self.tickers:
                    strategy_name = self.select_strategy(weights)
                    self.analyze_ticker(ticker, strategy_name)
                    time.sleep(1)  # API 호출 제한 고려
                
                # 포지션 업데이트
                self.update_all_positions()
                
                # 주기적 상태 출력 (10사이클마다)
                if cycle % 10 == 0:
                    self.print_status()
                    
                    # 성과 로그
                    risk_status = self.risk_manager.get_risk_status()
                    self.logger.log_performance(
                        total_profit=risk_status['cumulative_profit_loss'],
                        win_rate=risk_status['win_rate'],
                        total_trades=risk_status['total_trades'],
                        current_balance=risk_status['current_balance'],
                        daily_profit=risk_status['daily_profit_loss']
                    )
                
                # 대기 (5분)
                time.sleep(300)
        
        except KeyboardInterrupt:
            self.logger.log_info("⏹️ 사용자에 의해 중지됨")
        except Exception as e:
            self.logger.log_error("RUNTIME_ERROR", "봇 실행 중 오류", e)
        finally:
            self.stop()
    
    def stop(self):
        """봇 중지"""
        self.running = False
        self.logger.log_info("🛑 봇 종료")
        
        # 최종 상태 출력
        self.print_status()


def main():
    """메인 함수"""
    parser = argparse.ArgumentParser(description='Upbit AutoProfit Bot')
    parser.add_argument(
        '--mode',
        type=str,
        choices=['backtest', 'paper', 'live'],
        default='backtest',
        help='거래 모드 선택'
    )
    
    args = parser.parse_args()
    
    # 실거래 모드 경고
    if args.mode == 'live':
        print("=" * 60)
        print("⚠️  경고: 실거래 모드로 실행합니다!")
        print("⚠️  실제 자금이 사용되며 손실이 발생할 수 있습니다!")
        print("=" * 60)
        confirm = input("계속하시겠습니까? (yes/no): ")
        if confirm.lower() != 'yes':
            print("취소되었습니다.")
            return
    
    # 봇 실행
    bot = AutoProfitBot(mode=args.mode)
    bot.run()


if __name__ == "__main__":
    main()
