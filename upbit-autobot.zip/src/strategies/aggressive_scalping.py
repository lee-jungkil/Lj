"""
극공격적 단타 전략 (Aggressive Scalping)
짧은 시간 내 작은 가격 변동으로 수익 추구
"""

from typing import Dict, Tuple
import pandas as pd
from .base_strategy import BaseStrategy


class AggressiveScalping(BaseStrategy):
    """극공격적 단타 전략"""
    
    def __init__(self, config: Dict):
        super().__init__("AggressiveScalping", config)
        
        # 전략 파라미터
        self.stop_loss = config.get('stop_loss', 0.02)  # 2%
        self.take_profit = config.get('take_profit', 0.015)  # 1.5%
        self.rsi_oversold = config.get('rsi_oversold', 30)
        self.rsi_overbought = config.get('rsi_overbought', 70)
        self.volume_threshold = config.get('volume_threshold', 1.5)
        self.min_price_change = config.get('min_price_change', 0.01)  # 1%
    
    def generate_signal(self, df: pd.DataFrame, ticker: str) -> Tuple[str, str, Dict]:
        """
        매매 신호 생성
        
        조건:
        - RSI < 30 (과매도) 또는 RSI > 70 (과매수)
        - 5분봉 기준 1% 이상 급등/급락
        - 거래량 평균 대비 150% 이상
        
        Returns:
            (신호, 사유, 지표)
        """
        if not self.enabled or not self.is_valid_data(df):
            return 'HOLD', 'Invalid data', {}
        
        # 기술적 지표 계산
        rsi = self.calculate_rsi(df)
        volume_ratio = self.calculate_volume_ratio(df)
        price_change = self.get_price_change(df, periods=1)
        
        current_rsi = rsi.iloc[-1]
        current_price = df['close'].iloc[-1]
        
        indicators = {
            'rsi': current_rsi,
            'volume_ratio': volume_ratio,
            'price_change': price_change,
            'current_price': current_price
        }
        
        # 매수 신호
        if (current_rsi < self.rsi_oversold and 
            volume_ratio >= self.volume_threshold and
            abs(price_change) >= self.min_price_change):
            reason = f"과매도 + 거래량 급증 (RSI: {current_rsi:.1f}, 거래량 비율: {volume_ratio:.2f}x, 변동: {price_change:+.2f}%)"
            return 'BUY', reason, indicators
        
        # 매도 신호 (이미 보유 중일 때)
        if current_rsi > self.rsi_overbought:
            reason = f"과매수 영역 (RSI: {current_rsi:.1f})"
            return 'SELL', reason, indicators
        
        return 'HOLD', 'No clear signal', indicators
    
    def should_exit(self, entry_price: float, current_price: float) -> Tuple[bool, str]:
        """
        청산 여부 확인
        
        Args:
            entry_price: 진입 가격
            current_price: 현재 가격
        
        Returns:
            (청산 여부, 사유)
        """
        profit_loss_ratio = (current_price - entry_price) / entry_price
        
        # 손절
        if profit_loss_ratio <= -self.stop_loss:
            return True, f"손절 ({profit_loss_ratio*100:.2f}%)"
        
        # 익절
        if profit_loss_ratio >= self.take_profit:
            return True, f"익절 ({profit_loss_ratio*100:.2f}%)"
        
        return False, "Hold position"
