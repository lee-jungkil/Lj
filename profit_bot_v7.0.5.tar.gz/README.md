# 🎯 Profit Bot v7.0.4 - 수익 최적화 자동매매 봇

> **업비트 자동매매 봇 - 간결함 · 명확함 · 수익성 · 학습 · 안전성**

[![Version](https://img.shields.io/badge/version-7.0.4-blue.svg)](https://github.com/lee-jungkil/Lj)
[![Python](https://img.shields.io/badge/python-3.8+-green.svg)](https://www.python.org/)
[![Status](https://img.shields.io/badge/status-production%20ready-brightgreen.svg)](https://github.com/lee-jungkil/Lj)

---

## 📥 다운로드 (v7.0.4)

### Windows 사용자
**ZIP 파일**: [profit_bot_v7.0.4.zip](https://www.genspark.ai/api/files/s/HlVyVg22) (277 KB)

### Linux/Mac 사용자
**TAR.GZ 파일**: [profit_bot_v7.0.4.tar.gz](https://www.genspark.ai/api/files/s/aOQw3emE) (233 KB)

📖 **변경 사항**:
- **v7.0.4**: [CHANGES_v7.0.4.md](CHANGES_v7.0.4.md) - 볼린저 밴드 + 스토캐스틱 진입조건 추가
- **v7.0.3**: [CHANGES_v7.0.3.md](CHANGES_v7.0.3.md) - 청산조건 개선 및 포지션 관리 강화
- **v7.0.2**: [DOWNLOAD_v7.0.2.md](DOWNLOAD_v7.0.2.md) - 스캐닝 성능 최적화

---

## 🚀 빠른 시작 (3단계)

### 1️⃣ 테스트 (필수!)
```bash
더블클릭: TEST_v7.0.bat
```

### 2️⃣ 시뮬레이션
```bash
더블클릭: RUN_PAPER_v7.0.bat
```

### 3️⃣ 실전 (신중!)
```bash
더블클릭: RUN_LIVE_v7.0.bat
```

---

## 📊 핵심 기능

### ✅ 수익 최적화 전략 (v7.0.4 강화)
```
✅ 진입: 6가지 조건
   - 거래량 급증(2.5x) + 모멘텀(0.15-1.5%)
   - RSI 과매도(< 35) + 호가창 매도압력(<60%)
   - 볼린저 밴드 하단 근처(±5%) ⭐ NEW
   - 스토캐스틱 과매도 탈출(20-40, K>D) ⭐ NEW
✅ 청산: 7가지 조건 (손절 -0.5%, 익절 +0.5%, 시간 300초 등)
✅ 포지션: 기본 5개, 최대 10개 (강화 진입조건)
✅ 검증: 모든 테스트 통과
```

### ✅ 실시간 학습
```
✅ 매 거래마다 학습 → 10건마다 최적화
✅ 승률 < 40% → 진입 조건 강화
✅ 승률 > 60% → 진입 조건 완화
✅ 파라미터 자동 조정 (±5%)
```

### ✅ 간결한 코드
```
기존: 132KB, 3500줄 → v7.0: 17KB, 500줄 (87% 감소!)
✅ 읽기 쉬움
✅ 디버그 가능
✅ 수정 용이
```

---

## 💰 기대 성과

| 지표 | 목표 |
|------|------|
| **일일 수익** | 1-3% |
| **승률** | 60% 이상 |
| **Profit Factor** | 2.0 이상 |
| **거래당 수익** | 0.3-0.8% |
| **손실 제한** | 최대 -0.5% |

---

## 📁 파일 구조

```
Lj/
├── 🚀 실행 파일
│   ├── TEST_v7.0.bat              ⭐ 테스트 (필수!)
│   ├── RUN_PAPER_v7.0.bat         ⭐ 시뮬레이션
│   └── RUN_LIVE_v7.0.bat          ⭐ 실전 (신중!)
│
├── 🎯 핵심 파일
│   ├── profit_bot_v7.py           메인 봇
│   ├── test_quick_v7.py           테스트 스크립트
│   └── src/
│       ├── strategies/
│       │   └── profit_optimized_strategy.py
│       ├── ai/
│       │   └── realtime_learner.py
│       ├── config.py              ⚙️ 설정 (API 키)
│       └── utils/
│
└── 📚 문서
    ├── README_V7.md               빠른 시작
    ├── USER_GUIDE_V7.md           사용자 가이드
    ├── PROFIT_BOT_V7_FINAL_REPORT.md
    ├── COMPARISON_OLD_VS_V7.md
    ├── COMPLETE_VERIFICATION_REPORT.md
    └── FINAL_DELIVERY_REPORT.md
```

---

## ⚙️ 설치 및 설정

### 1. Python 설치
- Python 3.8 이상 필요
- [다운로드](https://www.python.org/downloads/)

### 2. 라이브러리 설치
```bash
pip install -r requirements.txt
```

### 3. API 키 설정 (실전 모드만)
`src/config.py` 파일 수정:
```python
UPBIT_ACCESS_KEY = "여기에_입력"
UPBIT_SECRET_KEY = "여기에_입력"
```

---

## 🧪 테스트

**더블클릭**: `TEST_v7.0.bat`

**예상 결과**:
```
🎉 모든 테스트 통과!
✅ [1] 모듈 임포트: PASS
✅ [2] 전략 생성: PASS
✅ [3] 학습 시스템: PASS
✅ [4] 봇 생성: PASS
✅ [5] 진입/청산 로직: PASS
✅ [6] 학습 시스템: PASS
```

---

## 🎮 실행 방법

### 시뮬레이션 모드 (권장)

**더블클릭**: `RUN_PAPER_v7.0.bat`

**특징**:
- ✅ 실제 시장 데이터 사용
- ✅ 실제 주문은 하지 않음
- ✅ 안전하게 전략 검증
- ✅ 학습 데이터 축적

**권장 기간**: 1-3일

### 실전 모드 (신중!)

**더블클릭**: `RUN_LIVE_v7.0.bat`

**준비사항**:
1. ✅ 시뮬레이션 완료 (1-3일)
2. ✅ 수익성 확인 (PF > 2.0, 승률 > 60%)
3. ✅ API 키 설정 (`src/config.py`)
4. ✅ 소액 시작 (10-50만원)

---

## 📊 성과 모니터링

### 로그 확인
```bash
# 실시간 로그
tail -f profit_bot.log

# 학습 데이터
cat src/learning_data/realtime_learning.json
```

### 성과 요약 (60초마다)
```
======================================================================
📊 성과 요약
----------------------------------------------------------------------
   총 거래: 15건
   승률: 66.7% (10/15)
   총 수익: +4,250원
   오늘 수익: +4,250원
   현재 포지션: 1개
   학습 승률: 66.7%
   Profit Factor: 2.15
======================================================================
```

---

## 🎓 핵심 개념

### 수익 전략
```
거래량 급증 감지 (2.5x)
    ↓
가격 모멘텀 확인 (0.15-1.5%)
    ↓
RSI + 호가창 체크
    ↓
✅ 진입 (시장가 매수)
    ↓
7가지 청산 조건 감시 (3초마다)
    ↓
조건 충족 → 즉시 청산 ✅
```

### 학습 시스템
```
거래 10건 → 학습 → 파라미터 조정 (±5%) → 다음 거래에 즉시 적용 ✅
```

---

## ⚠️ 주의사항

### ✅ DO
1. ✅ 테스트 먼저 실행 (`TEST_v7.0.bat`)
2. ✅ 시뮬레이션 충분히 (1-3일)
3. ✅ 소액으로 시작 (10-50만원)
4. ✅ 로그 확인 (`tail -f profit_bot.log`)
5. ✅ 학습 데이터 확인 (`src/learning_data/`)

### ❌ DON'T
1. ❌ 테스트 없이 실전
2. ❌ 큰 금액으로 시작
3. ❌ 로그 무시
4. ❌ 네트워크 불안정한 환경
5. ❌ API 키 공유

---

## 📚 문서

| 문서 | 설명 |
|------|------|
| [USER_GUIDE_V7.md](USER_GUIDE_V7.md) | 사용자 가이드 (설치, 실행, 모니터링) |
| [PROFIT_BOT_V7_FINAL_REPORT.md](PROFIT_BOT_V7_FINAL_REPORT.md) | 상세 기술 보고서 |
| [COMPARISON_OLD_VS_V7.md](COMPARISON_OLD_VS_V7.md) | 기존 봇 vs v7.0 비교 |
| [COMPLETE_VERIFICATION_REPORT.md](COMPLETE_VERIFICATION_REPORT.md) | 완전 검증 보고서 |

---

## 🆚 기존 봇과의 차이

| 항목 | 기존 main.py | Profit Bot v7.0 |
|------|-------------|-----------------|
| 코드 크기 | 132KB, 3500줄 | 17KB, 500줄 ✅ |
| 진입 조건 | 45개 시나리오 | 4개 조건 ✅ |
| 청산 로직 | 버그 多 | 정상 작동 ✅ |
| 학습 시스템 | 미작동 | 실시간 ✅ |
| 디버그 | 불가능 | 가능 ✅ |
| 테스트 | 실패 | 통과 ✅ |

---

## 🔧 문제 해결

### Q1: 봇이 바로 종료됩니다
```
✅ 해결됨: v7.0.2에서 성능 최적화 완료
- 스캔 속도가 25초로 개선되었습니다
- 정상적으로 실행됩니다
- 30초마다 자동으로 스캔합니다
```

### Q2: 봇이 실행되지 않습니다
```bash
# Python 버전 확인
python --version
# Python 3.8 이상 필요

# 라이브러리 설치
pip install -r requirements.txt
```

### Q3: API 키 오류
```bash
# src/config.py 파일 확인
# UPBIT_ACCESS_KEY와 UPBIT_SECRET_KEY 설정 확인
```

### Q4: 배치 파일 실행 시 한글이 깨집니다
```
✅ 해결됨: v7.0.1부터 배치 파일이 영어로만 작성되어 있습니다
- 모든 메시지가 영어로 표시됩니다
- Windows 인코딩 문제 완전 해결
- 정상적으로 동작합니다
```

### Q5: 더 자세한 도움이 필요합니다
- [USER_GUIDE_V7.md](USER_GUIDE_V7.md) 참조
- [GitHub Issues](https://github.com/lee-jungkil/Lj/issues)

---

## 📝 변경 이력

### v7.0.4 (2026-07-27) - 기술적 지표 강화 ⭐ NEW
- ✅ **볼린저 밴드** 진입조건 추가 (하단 ±5% 과매도 탐지)
- ✅ **스토캐스틱** 진입조건 추가 (20-40 구간, 상승 모멘텀 확인)
- ✅ 2단계 포지션 관리 (0-5: 일반, 6-10: 강화 조건)
- ✅ 예상 승률 개선: 60% → 70%+
- 📖 상세: [CHANGES_v7.0.4.md](CHANGES_v7.0.4.md)

### v7.0.3 (2026-07-24) - 청산 및 포지션 관리 개선
- ✅ 시간 기반 청산: 180초 → 300초 (수익 >= 0.2% 조건 추가)
- ✅ 포지션 관리: 최대 3개 → 기본 5개 / 최대 10개
- ✅ 6-10번 포지션: 강화된 진입조건 적용
- ✅ 트레일링 스탑 설명 추가
- 📖 상세: [CHANGES_v7.0.3.md](CHANGES_v7.0.3.md)

### v7.0.2 (2026-07-22) - 성능 최적화
- ✅ 스캔 속도 대폭 개선 (2분+ → 25초)
- ✅ API 호출 80% 감소 (2단계 스캔 도입)
- ✅ 실행 시 바로 종료되는 문제 해결
- ✅ 메모리 사용량 감소

### v7.0.1 (2026-07-22) - 한글 인코딩 수정
- ✅ 배치 파일 한글 제거 (영어로 변경)
- ✅ Windows 인코딩 문제 완전 해결
- ✅ 모든 Windows 환경에서 정상 동작

### v7.0 (2026-07-22) - 완전 재설계
- ✅ 새로운 수익 전략 구현
- ✅ 실시간 학습 시스템
- ✅ 코드 87% 감소
- ✅ 모든 테스트 통과
- ✅ 실행 배치파일 제공

---

## 📄 라이선스

MIT License

---

## 🎯 목표

**일일 수익률 1-3% 달성!**

---

**⚡ 지금 바로 시작하세요!**

1. 더블클릭: `TEST_v7.0.bat` (테스트)
2. 더블클릭: `RUN_PAPER_v7.0.bat` (시뮬레이션)
3. 더블클릭: `RUN_LIVE_v7.0.bat` (실전)

**✅ 버전**: v7.0.2 (Performance Optimized)  
**✅ 상태**: Production Ready  
**✅ 최종 업데이트**: 2026-07-22  
**✅ 스캔 속도**: ~25초 (빠름!)
